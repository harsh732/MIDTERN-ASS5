﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ASS5
{
    class VM : INotifyPropertyChanged
    {
        ObservableCollection<Data> _myList = new ObservableCollection<Data>();

        decimal _speed;

        public decimal Speed
        {
            get { return _speed; }
            set { _speed = value;OnPropertyChanged(); }
        }

        decimal _time;

        public decimal Time
        {
            get { return _time; }
            set { _time = value;OnPropertyChanged(); }
        }

        public ObservableCollection<Data> MyList
        {
            get { return _myList; }
            set { _myList = value;OnPropertyChanged(); }
        }

        public void Calculate()
        {
            decimal distance;
            for (int i = 0; i < _time; i++)
            {
                  distance = _speed * i;
               // distance = Convert.ToDecimal(Math.Pow(2, i));
                
                Data d = new Data();
                d.Value1 = distance;
                _myList.Add(d);
            }


        }


        public void Save()
        {
            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string fullpath = Path.Combine(path, "PROG80");
            Directory.CreateDirectory(fullpath);
            string fullname = Path.Combine(fullpath,"demo.txt");
            StreamWriter sw = File.AppendText(fullname);
            foreach(Data d in _myList)
            {
                sw.Write(" ");
                sw.WriteLine(d.ToString());

            }
            sw.Close();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = "")
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
