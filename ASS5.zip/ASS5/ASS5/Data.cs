﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASS5
{
    class Data
    {
        public decimal Value1 { get; set; }

        public override string ToString()
        {
            return Value1.ToString();
        }

    }
}
